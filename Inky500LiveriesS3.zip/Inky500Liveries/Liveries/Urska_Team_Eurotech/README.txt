These livery files are provided as is by lightbot
at "Awesome Simracing" on http://default/livery/badger-team-eurotech-ecotune-652.
The files are supposed for personal use case only.
Please contact the original author and/or artist for any inquiries.